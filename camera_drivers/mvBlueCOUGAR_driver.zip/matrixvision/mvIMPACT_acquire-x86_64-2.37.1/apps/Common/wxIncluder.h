//-----------------------------------------------------------------------------
#ifndef wxIncluderH
#define wxIncluderH wxIncluderH
//-----------------------------------------------------------------------------
#include <apps/Common/wxIncludePrologue.h>
#include "wx/wx.h"
#include <apps/Common/wxIncludeEpilogue.h>

#endif // wxIncluderH
