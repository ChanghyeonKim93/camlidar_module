//-----------------------------------------------------------------------------
#ifndef InfoH
#define InfoH InfoH
//-----------------------------------------------------------------------------

#define COMPANY_NAME "MATRIX VISION GmbH"
#define COMPANY_WEBSITE "www.matrix-vision.com"
#define COMPANY_SUPPORT_MAIL "mailto:support@matrix-vision.com"
#define CURRENT_YEAR "2020"
#define VERSION_STRING "2.37.1.2900"

#endif // InfoH
