//-----------------------------------------------------------------------------
#ifndef InfoH
#define InfoH InfoH
//-----------------------------------------------------------------------------

#define COMPANY_NAME wxT("MATRIX VISION GmbH")
#define COMPANY_WEBSITE wxT("www.matrix-vision.com")
#define COMPANY_SUPPORT_MAIL wxT("mailto:support@matrix-vision.com")
#define CURRENT_YEAR wxT("2020")
#define VERSION_STRING wxT("2.37.1.2900")

#endif // InfoH
