//-----------------------------------------------------------------------------
#ifndef ValuesFromUserDlgH
#define ValuesFromUserDlgH ValuesFromUserDlgH
//-----------------------------------------------------------------------------
#include <mvIMPACT_CPP/mvIMPACT_acquire.h>
#include <mvIMPACT_CPP/mvIMPACT_acquire_GenICam.h>

#include <apps/Common/wxIncludePrologue.h>
#include <wx/wx.h>
#include <apps/Common/wxIncludeEpilogue.h>

class wxCheckListBox;
class PropData;

typedef std::map<wxString, wxString> StringToStringMap;

//-----------------------------------------------------------------------------
class OkAndCancelDlg : public wxDialog
//-----------------------------------------------------------------------------
{
    DECLARE_EVENT_TABLE()
protected:
    wxButton*                   pBtnApply_;
    wxButton*                   pBtnCancel_;
    wxButton*                   pBtnOk_;

    virtual void OnBtnApply( wxCommandEvent& ) {}
    virtual void OnBtnCancel( wxCommandEvent& )
    {
        EndModal( wxID_CANCEL );
    }
    virtual void OnBtnOk( wxCommandEvent& )
    {
        EndModal( wxID_OK );
    }
    virtual void OnBtnDownloadFWBCX( wxCommandEvent& )
    {
        EndModal( wxID_FILE1 );
    }
    virtual void OnBtnDownloadFWBF3( wxCommandEvent& )
    {
        EndModal( wxID_FILE2 );
    }
    virtual void OnBtnDownloadFWBCXAndBF3( wxCommandEvent& )
    {
        EndModal( wxID_FILE3 );
    }
    void AddButtons( wxWindow* pWindow, wxSizer* pSizer, bool boCreateApplyButton = false );
    void FinalizeDlgCreation( wxWindow* pWindow, wxSizer* pSizer );
    //-----------------------------------------------------------------------------
    enum TWidgetIDs
    //-----------------------------------------------------------------------------
    {
        widBtnOk = 1,
        widBtnCancel = 2,
        widBtnApply = 3,
        widBtnDownloadFWBF3 = 4,
        widBtnDownloadFWBCX = 5,
        widBtnDownloadFWBCXAndBF3 = 6,
        widFirst = 100
    };
public:
    explicit OkAndCancelDlg( wxWindow* pParent, wxWindowID id, const wxString& title, const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize, long style = wxDEFAULT_DIALOG_STYLE, const wxString& name = wxT( "OkAndCancelDlg" ) );
};

//-----------------------------------------------------------------------------
class UpdatesInformationDlg : public OkAndCancelDlg
//-----------------------------------------------------------------------------
{
    DECLARE_EVENT_TABLE()

    const wxString currentVersion_;
    const wxString lastVersionDateBF3_;
    const wxString lastVersionDateBCX_;
    const wxString newestVersionDateBF3_;
    const wxString newestVersionDateBCX_;
    const wxString dateReleased_;
    const wxString whatsNew_;
    wxCheckBox* pCBAutoCheckForUpdatesWeekly_;

    virtual void OnClose( wxCloseEvent& )
    {
        EndModal( wxID_CANCEL );
    }
public:
    explicit UpdatesInformationDlg( wxWindow* pParent, const wxString& title,  const wxString lastVersionDateBF3_,
                                    const wxString newestVersionDateBCX_, const wxString& newestVersionDateBF3, const wxString& newestVersionDateBCX, const wxString& dateReleased, const wxString& whatsNew, const bool boCurrentAutoUpdateCheckState );
    bool GetAutoCheckForUpdatesWeeklyState( void ) const
    {
        return pCBAutoCheckForUpdatesWeekly_->GetValue();
    }
};

#endif // ValuesFromUserDlgH
