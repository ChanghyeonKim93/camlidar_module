//-----------------------------------------------------------------------------
#include <apps/Common/CommonGUIFunctions.h>
#include <apps/Common/wxAbstraction.h>
#include <common/STLHelper.h>
#include "ValuesFromUserDlg.h"

#include <apps/Common/wxIncludePrologue.h>
#include <wx/progdlg.h>
#include <apps/Common/wxIncludeEpilogue.h>

using namespace std;
using namespace mvIMPACT::acquire::GenICam;

//=============================================================================
//============== Implementation OkAndCancelDlg ================================
//=============================================================================
BEGIN_EVENT_TABLE( OkAndCancelDlg, wxDialog )
    EVT_BUTTON( widBtnOk, OkAndCancelDlg::OnBtnOk )
    EVT_BUTTON( widBtnCancel, OkAndCancelDlg::OnBtnCancel )
    EVT_BUTTON( widBtnApply, OkAndCancelDlg::OnBtnApply )
    EVT_BUTTON( widBtnDownloadFWBCX, OkAndCancelDlg::OnBtnDownloadFWBCX )
    EVT_BUTTON( widBtnDownloadFWBF3, OkAndCancelDlg::OnBtnDownloadFWBF3 )
    EVT_BUTTON( widBtnDownloadFWBCXAndBF3, OkAndCancelDlg::OnBtnDownloadFWBCXAndBF3 )
END_EVENT_TABLE()

//-----------------------------------------------------------------------------
OkAndCancelDlg::OkAndCancelDlg( wxWindow* pParent, wxWindowID id, const wxString& title, const wxPoint& pos /*= wxDefaultPosition*/,
                                const wxSize& size /*= wxDefaultSize*/, long style /*= wxDEFAULT_DIALOG_STYLE*/, const wxString& name /* = "OkAndCancelDlg" */ )
    : wxDialog( pParent, id, title, pos, size, style, name ), pBtnApply_( 0 ), pBtnCancel_( 0 ), pBtnOk_( 0 )
//-----------------------------------------------------------------------------
{

}

//-----------------------------------------------------------------------------
void OkAndCancelDlg::FinalizeDlgCreation( wxWindow* pWindow, wxSizer* pSizer )
//-----------------------------------------------------------------------------
{
    pWindow->SetSizer( pSizer );
    pSizer->SetSizeHints( this );
    SetClientSize( pSizer->GetMinSize() );
    SetSizeHints( GetSize() );
}

//=============================================================================
//=================== Implementation UpdatesInformationDlg ====================
//=============================================================================
BEGIN_EVENT_TABLE( UpdatesInformationDlg, OkAndCancelDlg )
    EVT_CLOSE( UpdatesInformationDlg::OnClose )
END_EVENT_TABLE()

//-----------------------------------------------------------------------------
UpdatesInformationDlg::UpdatesInformationDlg( wxWindow* pParent, const wxString& title,
        const wxString lastVersionDateBCX, const wxString lastVersionDateBF3, const wxString& newestVersionDateBF3, const wxString& newestVersionDateBCX, const wxString& dateReleased, const wxString& whatsNew, const bool boCurrentAutoUpdateCheckState ) :
    OkAndCancelDlg( pParent, wxID_ANY, title, wxDefaultPosition, wxDefaultSize ), lastVersionDateBF3_( lastVersionDateBF3 ), lastVersionDateBCX_( lastVersionDateBCX ), newestVersionDateBF3_( newestVersionDateBF3 ), newestVersionDateBCX_( newestVersionDateBCX ), dateReleased_( dateReleased ), whatsNew_( whatsNew )
//-----------------------------------------------------------------------------
{
    /*
    |-------------------------------------|
    | pTopDownSizer                       |
    |                spacer               |
    | |---------------------------------| |
    | |          Release Info           | |
    | |---------------------------------| |
    |                spacer               |
    | |---------------------------------| |
    | |            WhatsNew             | |
    | |---------------------------------| |
    |-------------------------------------|
    */

    wxBoxSizer* pTopDownSizer = new wxBoxSizer( wxVERTICAL );
    pTopDownSizer->AddSpacer( 20 );
    wxPanel* pPanel = new wxPanel( this );

    wxFont tmpFont = pPanel->GetFont();
    tmpFont.SetPointSize( pPanel->GetFont().GetPointSize() + 1 );

    wxStaticText* pVersionText = new wxStaticText( pPanel, wxID_ANY, ( lastVersionDateBCX < newestVersionDateBCX.AfterFirst( wxT( '-' ) ).AfterFirst( wxT( '-' ) ) || lastVersionDateBF3 < newestVersionDateBF3.AfterFirst( wxT( '-' ) ) ) ? wxT( "A newer firmware package has been released:" ) : wxT( "The newest Firmware package version has already been installed on your system:" ) );
    pVersionText->SetFont( tmpFont );
    wxTextCtrl* pWhatsNew = new wxTextCtrl( pPanel, wxID_ANY, whatsNew_, wxDefaultPosition, wxDefaultSize, wxTE_MULTILINE | wxBORDER_NONE | wxTE_RICH | wxTE_READONLY | wxTE_DONTWRAP );
    wxFont* fixedWidthFont = new wxFont( 8, wxFONTFAMILY_TELETYPE, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL );
    pWhatsNew->SetFont( *fixedWidthFont );
    pWhatsNew->ShowPosition( 0 );
    pTopDownSizer->Add( pVersionText, wxSizerFlags().Align( wxALIGN_CENTRE_HORIZONTAL ) );

    wxStaticText* pNewVersionBCX = 0;
    wxStaticText* pNewVersionBF3 = 0;
    if( lastVersionDateBCX < newestVersionDateBCX.AfterFirst( wxT( '-' ) ).AfterFirst( wxT( '-' ) ) || lastVersionDateBF3 < newestVersionDateBF3.AfterFirst( wxT( '-' ) ) )
    {
        pTopDownSizer->AddSpacer( 25 );
        static const wxString s_before181215( wxT( "before 181215" ) );
        if( lastVersionDateBCX < newestVersionDateBCX.AfterFirst( wxT( '-' ) ).AfterFirst( wxT( '-' ) ) )
        {
            pNewVersionBCX = new wxStaticText( pPanel, wxID_ANY, newestVersionDateBCX_ );
            pTopDownSizer->Add( pNewVersionBCX, wxSizerFlags().Align( wxALIGN_CENTRE_HORIZONTAL ) );
            pNewVersionBCX->SetForegroundColour( *wxBLUE );
            wxStaticText* pOldVersionBCX = new wxStaticText( pPanel, wxID_ANY, wxString::Format( wxT( "(current mvBlueCOUGAR-X(D) Firmware version: %s)" ), ( lastVersionDateBCX_.IsEmpty() ? s_before181215.c_str() : lastVersionDateBCX_.c_str() ) ) );
            pTopDownSizer->Add( pOldVersionBCX, wxSizerFlags().Align( wxALIGN_CENTRE_HORIZONTAL ) );
        }
        if( lastVersionDateBF3 < newestVersionDateBF3.AfterFirst( wxT( '-' ) ) )
        {
            pNewVersionBF3 = new wxStaticText( pPanel, wxID_ANY, newestVersionDateBF3_ );
            pTopDownSizer->Add( pNewVersionBF3, wxSizerFlags().Align( wxALIGN_CENTRE_HORIZONTAL ) );
            pNewVersionBF3->SetForegroundColour( *wxBLUE );
            wxStaticText* pOldVersionBF3 = new wxStaticText( pPanel, wxID_ANY, wxString::Format( wxT( "(current mvBlueFOX3 Firmware version: %s)" ), ( lastVersionDateBF3_.IsEmpty() ? s_before181215.c_str() : lastVersionDateBF3_.c_str() ) ) );
            pTopDownSizer->Add( pOldVersionBF3, wxSizerFlags().Align( wxALIGN_CENTRE_HORIZONTAL ) );
        }
    }
    else
    {
        pNewVersionBCX = new wxStaticText( pPanel, wxID_ANY, newestVersionDateBCX_ );
        pTopDownSizer->Add( pNewVersionBCX, wxSizerFlags().Align( wxALIGN_CENTRE_HORIZONTAL ) );
        pNewVersionBF3 = new wxStaticText( pPanel, wxID_ANY, newestVersionDateBF3_ );
        pTopDownSizer->Add( pNewVersionBF3, wxSizerFlags().Align( wxALIGN_CENTRE_HORIZONTAL ) );
    }

    pTopDownSizer->AddSpacer( 10 );
    wxStaticText* pDateText = new wxStaticText( pPanel, wxID_ANY, ( lastVersionDateBCX < newestVersionDateBCX.AfterFirst( wxT( '-' ) ).AfterFirst( wxT( '-' ) ) || lastVersionDateBF3 < newestVersionDateBF3.AfterFirst( wxT( '-' ) ) ) ? wxT( "Release date:" ) : wxEmptyString );
    pTopDownSizer->Add( pDateText, wxSizerFlags().Align( wxALIGN_CENTRE_HORIZONTAL ) );
    wxStaticText* pDate = new wxStaticText( pPanel, wxID_ANY, ( ( lastVersionDateBCX < newestVersionDateBCX.AfterFirst( wxT( '-' ) ).AfterFirst( wxT( '-' ) ) ) || ( lastVersionDateBF3 < newestVersionDateBF3.AfterFirst( wxT( '-' ) ) ) ) ? dateReleased_ : wxString( wxEmptyString ) );
    pTopDownSizer->Add( pDate, wxSizerFlags().Align( wxALIGN_CENTRE_HORIZONTAL ) );
    pTopDownSizer->AddSpacer( 10 );
    pTopDownSizer->AddSpacer( 25 );
    wxStaticText* pWhatsNewText = new wxStaticText( pPanel, wxID_ANY, wxT( "What's new:" ) );
    pTopDownSizer->Add( pWhatsNewText, wxSizerFlags().Align( wxALIGN_CENTRE_HORIZONTAL ) );
    pTopDownSizer->AddSpacer( 10 );
    pTopDownSizer->Add( pWhatsNew, wxSizerFlags().Expand() );
    pTopDownSizer->AddSpacer( 10 );

    pDateText->SetFont( tmpFont );
    pWhatsNewText->SetFont( tmpFont );
    tmpFont.SetWeight( wxFONTWEIGHT_BOLD );
    pDate->SetFont( tmpFont );
    tmpFont.SetPointSize( tmpFont.GetPointSize() + 1 );
    if( pNewVersionBCX )
    {
        pNewVersionBCX->SetFont( tmpFont );
    }
    if( pNewVersionBF3 )
    {
        pNewVersionBF3->SetFont( tmpFont );
    }
    // lower line of buttons
    wxBoxSizer* pButtonSizer = new wxBoxSizer( wxHORIZONTAL );
    pCBAutoCheckForUpdatesWeekly_ = new wxCheckBox( pPanel, wxID_ANY, wxT( "&Auto-Check For Updates Every Week..." ) );
    pCBAutoCheckForUpdatesWeekly_->SetValue( boCurrentAutoUpdateCheckState );
    pButtonSizer->Add( pCBAutoCheckForUpdatesWeekly_, wxSizerFlags().Border( wxALL, 7 ) );
    pButtonSizer->AddStretchSpacer( 100 );

    if( ( lastVersionDateBCX < newestVersionDateBCX.AfterFirst( wxT( '-' ) ).AfterFirst( wxT( '-' ) ) || lastVersionDateBCX == wxT( "None" ) || lastVersionDateBCX.IsEmpty() ) && ( lastVersionDateBF3 < newestVersionDateBF3.AfterFirst( wxT( '-' ) ) || lastVersionDateBF3 == wxT( "None" ) || lastVersionDateBF3.IsEmpty() ) )
    {
        pButtonSizer->Add( new wxButton( pPanel, widBtnDownloadFWBCXAndBF3, wxT( "Download FW BCX + BF3" ) ), wxSizerFlags().Border( wxALL, 7 ) );
    }
    if( lastVersionDateBCX < newestVersionDateBCX.AfterFirst( wxT( '-' ) ).AfterFirst( wxT( '-' ) ) || lastVersionDateBCX == wxT( "None" ) || lastVersionDateBCX.IsEmpty() )
    {
        pButtonSizer->Add( new wxButton( pPanel, widBtnDownloadFWBCX, wxT( "Download FW BCX" ) ), wxSizerFlags().Border( wxALL, 7 ) );
    }
    if( lastVersionDateBF3 < newestVersionDateBF3.AfterFirst( wxT( '-' ) ) || lastVersionDateBF3 == wxT( "None" ) || lastVersionDateBF3.IsEmpty() )
    {
        pButtonSizer->Add( new wxButton( pPanel, widBtnDownloadFWBF3, wxT( "Download FW BF3" ) ), wxSizerFlags().Border( wxALL, 7 ) );
    }

    pBtnCancel_ = new wxButton( pPanel, widBtnCancel, wxT( "&Ok" ) );
    pButtonSizer->Add( pBtnCancel_, wxSizerFlags().Border( wxALL, 7 ) );
    pTopDownSizer->Add( pButtonSizer, wxSizerFlags().Expand() );

    FinalizeDlgCreation( pPanel, pTopDownSizer );
    SetSize( 800, -1 );
    Center();
}
